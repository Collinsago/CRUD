<?php
$con = mysqli_connect('localhost','root','Collinsago@@@','user');
if($con){
	
}else{
	echo "Not Connected";
}

?>